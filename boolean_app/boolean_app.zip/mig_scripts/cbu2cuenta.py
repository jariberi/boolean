# -*- coding: utf-8 -*-

from boolean_app.models import Valores

if __name__ == "__main__":
    vals = Valores.objects.all()
    i = 0
    for val in vals:
        i+=1
        val.transferencia_cuenta_origen=val.transferencia_cbu_origen
        val.save()
        print "%s" %i