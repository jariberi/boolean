# -*- coding: utf-8 -*-

from geraldo import Report, ReportBand, Label, DetailBand

from geraldo.widgets import ObjectValue, SystemField
from reportlab.lib.enums import TA_RIGHT, TA_CENTER
from reportlab.lib.pagesizes import A4
from geraldo.utils import cm, landscape, BAND_WIDTH, FIELD_ACTION_SUM,\
    FIELD_ACTION_COUNT
from geraldo.base import SubReport, ReportBand, ReportGroup
from boolean.settings import RAZON_SOCIAL_EMPRESA, CUIT, DOMICILIO_COMERCIAL
from pdb import set_trace
from geraldo.graphics import Line, RoundRect
from reportlab.lib.colors import yellow, grey, black
from boolean_app.models import Venta, Recibo
from django.http.response import HttpResponse
from reportlab.pdfgen.canvas import Canvas
from decimal import Decimal
from datetime import datetime, date


class IVAVentas(Report):
    title = 'LIBRO IVA VENTAS - RESOLUCION GENERAL AFIP 3419'
    page_size = landscape(A4)
    
    def __init__(self, queryset=None, fpn=6):
        self.first_page_number=fpn
        Report.__init__(self, queryset=queryset)
        
    
    class band_page_header(ReportBand):    
        height = 4*cm
        elements = [SystemField(expression='%(report_title)s', top=0.1*cm, left=0, width=BAND_WIDTH, 
                                style={'fontName': 'Helvetica-Bold', 'fontSize': 14, 'alignment': TA_CENTER}),
                    Label(text="RAZON SOCIAL: %s" %RAZON_SOCIAL_EMPRESA, top=0.8*cm, width=BAND_WIDTH, 
                          style={'fontName':'Helvetica','fontSize':10}),
                    Label(text="CUIT: %s" %CUIT, top=1.2*cm, width=BAND_WIDTH, 
                          style={'fontName':'Helvetica','fontSize':10}),
                    Label(text="DOMICILIO COMERCIAL: %s" %DOMICILIO_COMERCIAL, top=1.5*cm, width=BAND_WIDTH, 
                          style={'fontName':'Helvetica','fontSize':10}),
                    SystemField(expression='Periodo: %(var:periodo)s', top=1.5*cm, left=23*cm, 
                          style={'fontName':'Helvetica','fontSize':10}), 
                    SystemField(expression='Fecha emisión: %(now:%d, %b %Y)s', top=2*cm, width=8*cm),
                    SystemField(expression='Folio N°: %(page_number)s', top=2*cm, left=23*cm, 
                          style={'fontName':'Helvetica','fontSize':10}),
                    Line(left=0, top=2.7*cm, right = 29.7*cm, bottom = 2.7*cm),
                    #Encabezado de tabla
                    Label(text="Fecha", top=2.9*cm, left=0, width=2*cm, style={'fontName':'Helvetica-Bold','fontSize':10,'alignment':TA_CENTER}),
                    Label(text="Comprobante", top=2.9*cm, left=2.1*cm, width=3.5*cm, style={'fontName':'Helvetica-Bold','fontSize':10,'alignment':TA_CENTER}),
                    Label(text="Razón Social", top=2.9*cm, left=5.7*cm, width=7*cm, style={'fontName':'Helvetica-Bold','fontSize':10,'alignment':TA_CENTER}),
                    Label(text="CUIT", top=2.9*cm, left=13.7*cm, width=2.5*cm, style={'fontName':'Helvetica-Bold','fontSize':10,'alignment':TA_CENTER}),
                    Label(text="Imp. Neto", top=2.9*cm, left=17.2*cm, width=2*cm, style={'fontName':'Helvetica-Bold','fontSize':10,'alignment':TA_CENTER}),
                    Label(text="IVA(10.5%)", top=2.9*cm, left=20.2*cm, width=2*cm, style={'fontName':'Helvetica-Bold','fontSize':10,'alignment':TA_CENTER}),
                    Label(text="IVA(21%)", top=2.9*cm, left=22.2*cm, width=2*cm, style={'fontName':'Helvetica-Bold','fontSize':10,'alignment':TA_CENTER}),
                    Label(text="Exento", top=2.9*cm, left=23.7*cm,width=2*cm, style={'fontName':'Helvetica-Bold','fontSize':10,'alignment':TA_CENTER}),
                    Label(text="Imp. Total", top=2.9*cm, left=26*cm, width=2*cm, style={'fontName':'Helvetica-Bold','fontSize':10,'alignment':TA_CENTER}),
                    Line(left=0, top=3.5*cm, right = 29.7*cm, bottom = 3.5*cm),]
        
    class band_detail(DetailBand):
        height = 0.4*cm
        elements = [ObjectValue(attribute_name='fecha_dd_mm_aaaa', top=0, left=0, width=2*cm),
                    ObjectValue(attribute_name='comp_completo_informe', top=0, left=2.1*cm, width=3.5*cm),
                    ObjectValue(attribute_name='cliente.razon_social', top=0, left=5.7*cm, width=7*cm, height=0.4*cm, truncate_overflow=True),
                    ObjectValue(attribute_name='cliente.cuit', top=0, left=13.7*cm, width=2.5*cm),
                    ObjectValue(attribute_name='neto',get_value=lambda instance: "%.2f" %(instance.neto*-1) if instance.tipo.startswith("NC") else "%.2f" %instance.neto,\
                                top=0, left=16.9*cm, width=2*cm,\
                                style={'alignment':TA_RIGHT}),
                    Label(text="0.00", top=0*cm, left=19.7*cm, width=2*cm, style={'alignment':TA_RIGHT}),
                    ObjectValue(attribute_name='iva21',get_value=lambda instance: "%.2f" %(instance.iva21*-1) if instance.tipo.startswith("NC") else "%.2f" %instance.iva21,\
                                top=0, left=21.4*cm,width=2*cm, style={'alignment':TA_RIGHT}),
                    Label(text="0.00", top=0*cm, left=23.7*cm,width=2*cm, style={'alignment':TA_RIGHT}),
                    ObjectValue(attribute_name='total',get_value=lambda instance: "%.2f" %(instance.total*-1) if instance.tipo.startswith("NC") else "%.2f" %instance.total,\
                                top=0, left=26*cm, width=2*cm, style={'alignment':TA_RIGHT}),
                    ]
        
    class band_summary(ReportBand):
        margin_top = 2*cm
        height = 0.5*cm
        elements = [
            ObjectValue(attribute_name='neto', top=0.1*cm, left=16.9*cm, width=2*cm,\
                action=FIELD_ACTION_SUM, get_value=lambda instance: float("%.2f" %(instance.neto*-1) if instance.tipo.startswith("NC") else "%.2f" %instance.neto), style={'alignment':TA_RIGHT}),
            ObjectValue(attribute_name='iva21', top=0.1*cm, left=21.4*cm,width=2*cm,\
                action=FIELD_ACTION_SUM, get_value=lambda instance: float("%.2f" %(instance.iva21*-1) if instance.tipo.startswith("NC") else "%.2f" %instance.iva21), style={'alignment':TA_RIGHT}),
            ObjectValue(attribute_name='total', top=0.1*cm, left=26*cm, width=2*cm,\
                action=FIELD_ACTION_SUM, get_value=lambda instance: float("%.2f" %(instance.total*-1) if instance.tipo.startswith("NC") else "%.2f" %instance.total), style={'alignment':TA_RIGHT}),]
        borders = {'all': RoundRect(radius=5, fill_color=grey, fill=True)}   

def impr_comprobante(request, pk):
    venta = Venta.objects.get(pk=pk)
    if venta.aprobado:
        response = HttpResponse(content_type='application/pdf')
        response['Content-Disposition'] = 'filename="somefilename.pdf"'
        p = Canvas(response, pagesize=A4)
        #p.translate(cm,cm)
        #set_trace()
        p.setFont('Helvetica-Bold', 16)
        if venta.tipo[-1:] == 'A':
            p.drawString(10.7*cm, 28.2*cm, 'A')
        elif venta.tipo[-1:] == 'B':
            p.drawString(10.7*cm, 28.2*cm, 'B')
        p.setFont('Helvetica', 13)
        if venta.tipo[:2] == 'FA':
            p.drawString(12.7*cm, 26.8*cm, 'FACTURA')
        elif venta.tipo[:2] == 'NC':
            p.drawString(12.7*cm, 26.8*cm, 'NOTA DE CREDITO')
        elif venta.tipo[:2] == 'NC':
            p.drawString(12.7*cm, 26.8*cm, 'NOTA DE DEBITO')
        p.drawString(12.1*cm, 27.7*cm, "N° %s  -" %venta.pto_vta_full())
        p.drawString(14.5*cm, 27.7*cm, venta.num_comp_full())
        p.drawString(17.2*cm, 26*cm, venta.fecha_dd_mm_aaaa())
        p.setFont('Helvetica', 10)
        p.drawString(3.25*cm, 23.1*cm, "%s" %venta.cliente.id)
        p.drawString(4.5*cm, 23.1*cm, venta.cliente.razon_social)
        p.drawString(4.5*cm, 22.0*cm, venta.cliente.direccion)
        p.drawString(16*cm, 23*cm, venta.cliente.cuit)
        p.drawString(16*cm, 22.5*cm, venta.cliente.localidad)
        p.drawString(16*cm, 22*cm, venta.cliente.provincia)
        p.drawString(7*cm, 21.0*cm, venta.condicion_venta.descripcion)
        detalle = venta.detalle_venta_set.all()
        inicio_y = 19.5
        alto_item = 0.4
        i = 0
        p.setFont('Helvetica', 7)
        for item in detalle:
            p.drawString(4*cm, (inicio_y-i*alto_item)*cm, "" if str(item.get_cod()) == "0" else str(item.get_cod())+"    "+str(item.get_cod_fab()))
            p.drawString(8*cm, (inicio_y-i*alto_item)*cm, "%.2f" %item.cantidad)
            p.drawString(9*cm, (inicio_y-i*alto_item)*cm, item.get_articulo()[:45])
            p.drawRightString(16.3*cm, (inicio_y-i*alto_item)*cm, "%.2f" %(item.precio_unitario if venta.tipo[-1:] == 'A' else item.precio_unitario*Decimal(1.21)))
            p.setFont('Helvetica', 5)
            p.drawRightString(17.3*cm, (inicio_y-i*alto_item)*cm, "-%.2f%%" %(item.descuento))
            p.setFont('Helvetica', 7)
            p.drawRightString(18.8*cm, (inicio_y-i*alto_item)*cm, "%.2f" %(item.neto() if venta.tipo[-1:] == 'A' else item.neto()*Decimal(1.21)))
            i+=1
        p.setFont('Helvetica', 12)
        p.drawString(15*cm, 5.5*cm, "Subtotal")
        p.drawRightString(18.5*cm, 5.5*cm, "%.2f" %(venta.subtotal if venta.tipo[-1:] == 'A' else venta.subtotal))
        p.drawString(15*cm, 5*cm, "Descuento")
        p.drawRightString(18.5*cm, 5*cm, "-%.2f" %venta.descuento_importe())
        p.drawString(15*cm, 4.5*cm, "Neto")
        p.drawRightString(18.5*cm, 4.5*cm, "%.2f" %(venta.neto if venta.tipo[-1:] == 'A' else venta.total))
        p.drawString(15*cm, 4*cm, "IVA 21%")
        p.drawRightString(18.5*cm, 4*cm, "%.2f" %(venta.iva21 if venta.tipo[-1:] == 'A' else 0.00))
        p.setFont('Helvetica-Bold', 12)
        p.drawString(15*cm, 3.3*cm, "Total")
        p.drawRightString(18.5*cm, 3.3*cm, "%.2f" %venta.total)
        p.setFont('Helvetica', 13)
        p.drawString(15*cm, 1.7*cm, "CAE: %s" %venta.cae)
        p.drawString(15*cm, 1.2*cm, "Fecha Vto: %s" %venta.vto_cae_dd_mm_aaaa())
        p.showPage()
        p.save()
        return response
    
def impr_recibo(request,pk):
    mitad = 14.8*cm
    mita = 14.8
    recibo = Recibo.objects.get(pk=pk)
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'filename="somefilename.pdf"'
    p = Canvas(response, pagesize=A4)
    #Numero de recibo
    p.setFont('Helvetica-Bold', 16)
    p.drawString(15.7*cm, 13*cm, recibo.numero_full)
    #Fecha
    p.setFont('Helvetica', 13)
    p.drawString(17*cm, 12*cm, str(recibo.fecha.day))
    p.drawString(18*cm, 12*cm, str(recibo.fecha.month))
    p.drawString(19*cm, 12*cm, str(recibo.fecha.year))
    #Datos del cliente
    p.setFont('Helvetica', 13)
    p.drawString(12*cm, 11*cm, recibo.cliente.razon_social)
    p.drawString(12*cm, 10.3*cm, recibo.cliente.cond_iva)
    p.drawString(12*cm, 9.8*cm, "CUIT: %s" %recibo.cliente.cuit)
    p.drawString(12*cm, 9.3*cm, recibo.cliente.direccion)
    p.drawString(12*cm, 8.8*cm, "%s - %s" %(recibo.cliente.localidad, recibo.cliente.provincia))
    #Datos de comprobantes
    comprobantes = recibo.detalle_cobro_set.all()
    inicio_y = 6.2
    alto_item = 0.4
    i = 0
    p.setFont('Helvetica', 7)
    for item in comprobantes:
        p.drawString(2*cm, (inicio_y-i*alto_item)*cm, item.venta.tipo)
        p.drawString(3.4*cm, (inicio_y-i*alto_item)*cm, item.venta.num_comp_full())
        p.drawString(5.1*cm, (inicio_y-i*alto_item)*cm, item.venta.fecha_dd_mm_aaaa())
        p.drawRightString(7.4*cm, (inicio_y-i*alto_item)*cm, item.monto_2d())
        i+=1
    valores = recibo.valores_set.all()
    i=0
    for item in valores:
        p.drawString(10*cm, (inicio_y-i*alto_item)*cm, item.cheque_numero if item.tipo=='CHT' else item.tipo)
        p.drawString(11.7*cm, (inicio_y-i*alto_item)*cm, item.cheque_cuit_titular)
        p.drawString(13.8*cm, (inicio_y-i*alto_item)*cm, item.cheque_fecha_dd_mm_aaaa())
        p.drawString(15.4*cm, (inicio_y-i*alto_item)*cm, item.cheque_banco.nombre[:20] if item.tipo=='CHT' else "")
        p.drawRightString(20*cm, (inicio_y-i*alto_item)*cm, item.monto_2d())
        i+=1
    p.setFont('Helvetica-Bold', 12)
    p.drawString(7.5*cm, 2.3*cm, recibo.total_str)
    p.drawString(18*cm, 2.3*cm, recibo.total_str)  
    ######################################################
    ##############RECIBO DUPLICADO########################
    ######################################################
    #Numero de recibo
    p.setFont('Helvetica-Bold', 16)
    p.drawString(15.7*cm, mitad+13*cm, recibo.numero_full)
    #Fecha
    p.setFont('Helvetica', 13)
    p.drawString(17*cm, mitad+12*cm, str(recibo.fecha.day))
    p.drawString(18*cm, mitad+12*cm, str(recibo.fecha.month))
    p.drawString(19*cm, mitad+12*cm, str(recibo.fecha.year))
    #Datos del cliente
    p.setFont('Helvetica', 13)
    p.drawString(12*cm, mitad+11*cm, recibo.cliente.razon_social)
    p.drawString(12*cm, mitad+10.3*cm, recibo.cliente.cond_iva)
    p.drawString(12*cm, mitad+9.8*cm, "CUIT: %s" %recibo.cliente.cuit)
    p.drawString(12*cm, mitad+9.3*cm, recibo.cliente.direccion)
    p.drawString(12*cm, mitad+8.8*cm, "%s - %s" %(recibo.cliente.localidad, recibo.cliente.provincia))
    #Datos de comprobantes
    #comprobantes = recibo.detalle_cobro_set.all()
    inicio_y = mita+6.2
    alto_item = 0.4
    i = 0
    p.setFont('Helvetica', 7)
    for item in comprobantes:
        p.drawString(2*cm, (inicio_y-i*alto_item)*cm, item.venta.tipo)
        p.drawString(3.4*cm, (inicio_y-i*alto_item)*cm, item.venta.num_comp_full())
        p.drawString(5.1*cm, (inicio_y-i*alto_item)*cm, item.venta.fecha_dd_mm_aaaa())
        p.drawRightString(7.4*cm, (inicio_y-i*alto_item)*cm, item.monto_2d())
        i+=1
    valores = recibo.valores_set.all()
    i=0
    for item in valores:
        p.drawString(10*cm, (inicio_y-i*alto_item)*cm, item.cheque_numero if item.tipo=='CHT' else item.tipo)
        p.drawString(11.7*cm, (inicio_y-i*alto_item)*cm, item.cheque_cuit_titular)
        p.drawString(13.8*cm, (inicio_y-i*alto_item)*cm, item.cheque_fecha_dd_mm_aaaa())
        p.drawString(15.4*cm, (inicio_y-i*alto_item)*cm, item.cheque_banco.nombre[:20] if item.tipo=='CHT' else "")
        p.drawRightString(20*cm, (inicio_y-i*alto_item)*cm, item.monto_2d())
        i+=1
    p.setFont('Helvetica-Bold', 12)
    p.drawString(7.5*cm, mitad+2.3*cm, recibo.total_str)
    p.drawString(18*cm, mitad+2.3*cm, recibo.total_str)
    p.showPage()
    p.save()
    return response

class ResumenCuenta(Report):
    title = 'RESUMEN DE CUENTA DE CLIENTES'
    page_size = A4
    margin_left = 1*cm
    margin_top = 1*cm
    margin_right = 1*cm
    margin_bottom = 1*cm
    
    class band_page_header(ReportBand):    
        height = 4*cm
        elements = [SystemField(expression='%(report_title)s', top=1.4*cm, left=0, width=BAND_WIDTH, 
                                style={'fontName': 'Helvetica-Bold', 'fontSize': 14, 'alignment': TA_CENTER}),
                    Label(text=RAZON_SOCIAL_EMPRESA, top=0.5*cm, width=BAND_WIDTH, 
                          style={'fontName':'Helvetica-Bold','fontSize':12, 'alignment': TA_CENTER}),
                    SystemField(expression='Fecha emisión: %(now:%d/%m/%Y)s', top=0*cm, left=14.4*cm, width=8*cm),
                    Line(left=0, top=2.5*cm, right = 21*cm, bottom = 2.5*cm),
                    #Encabezado de tabla
                    Label(text="Datos", top=2.7*cm, left=1*cm, width=2*cm, style={'fontName':'Helvetica-Bold','fontSize':12,'alignment':TA_CENTER}),
                    Label(text="Debe", top=2.7*cm, left=10*cm, width=3.5*cm, style={'fontName':'Helvetica-Bold','fontSize':12,'alignment':TA_CENTER}),
                    Label(text="Haber", top=2.7*cm, left=14*cm, width=3.5*cm, style={'fontName':'Helvetica-Bold','fontSize':12,'alignment':TA_CENTER}),
                    Label(text="Saldo", top=2.7*cm, left=17*cm, width=3.5*cm, style={'fontName':'Helvetica-Bold','fontSize':12,'alignment':TA_CENTER}),
                    Line(left=0, top=3.2*cm, right = 29.7*cm, bottom = 3.2*cm),]
        
    class band_detail(DetailBand):
        height = 0.5*cm
        elements = [
                    ObjectValue(attribute="", get_value=lambda instance:"%s" %instance['fecha'] if not isinstance(instance['fecha'], date) else "%s -- %s / %s" %(instance['fecha'].strftime("%d/%m/%Y"),instance['tipo'],instance['numero']),left=1*cm, width=6.5*cm),                
                    ObjectValue(attribute_name='debe',get_value=lambda instance: "%.2f" %instance['debe'] if isinstance(instance['debe'],Decimal) else instance['debe'],left=10*cm, width=2.5*cm,style={'alignment':TA_RIGHT}),
                    ObjectValue(attribute_name='haber',get_value=lambda instance: "%.2f" %instance['haber'] if isinstance(instance['haber'],Decimal) else instance['haber'],left=14*cm,width=2.5*cm,style={'alignment':TA_RIGHT}),
                    ObjectValue(attribute_name='saldo',get_value=lambda instance: "%.2f" %instance['saldo'] if isinstance(instance['saldo'],Decimal) else instance['saldo'],left=16.6*cm,width=2.5*cm,style={'alignment':TA_RIGHT}),      
                    ]
    groups=[
            ReportGroup(attribute_name='cliente_id',
                        band_header=ReportBand(
                                               height = 0.7*cm,
                                               borders = {'bottom': Line(stroke_color=black)},
                                               elements=[Label(text="CLIENTE:", top=0.1*cm, left=1*cm, 
                                                               style={'fontName':'Helvetica','fontSize':12}),
                                                         ObjectValue(attribute_name='cliente_id', top=0.1*cm, left=3*cm, style={'fontName':'Helvetica-Bold','fontSize':10}),
                                                         ObjectValue(attribute_name='razon_social', top=0.1*cm, left=4.5*cm, width=15*cm, style={'fontName':'Helvetica-Bold','fontSize':10}),
                                                         ])
                        )
            ]
    
class ComposicionSaldo(Report):
    title = 'COMPOSICION DE SALDO'
    page_size = A4
    margin_left = 1*cm
    margin_top = 1*cm
    margin_right = 1*cm
    margin_bottom = 1*cm
    
    class band_page_header(ReportBand):    
        height = 4*cm
        elements = [SystemField(expression='%(report_title)s', top=1.4*cm, left=0, width=BAND_WIDTH, 
                                style={'fontName': 'Helvetica-Bold', 'fontSize': 14, 'alignment': TA_CENTER}),
                    Label(text=RAZON_SOCIAL_EMPRESA, top=0.5*cm, width=BAND_WIDTH, 
                          style={'fontName':'Helvetica-Bold','fontSize':12, 'alignment': TA_CENTER}),
                    SystemField(expression='Fecha emisión: %(now:%d/%m/%Y)s', top=0*cm, left=14.4*cm, width=8*cm),
                    Line(left=0, top=2.5*cm, right = 21*cm, bottom = 2.5*cm),
                    #Encabezado de tabla
                    Label(text="Datos", top=2.7*cm, left=1*cm, width=2*cm, style={'fontName':'Helvetica-Bold','fontSize':12,'alignment':TA_CENTER}),
                    Label(text="Total", top=2.7*cm, left=10*cm, width=3.5*cm, style={'fontName':'Helvetica-Bold','fontSize':12,'alignment':TA_CENTER}),
                    Label(text="Saldo", top=2.7*cm, left=14*cm, width=3.5*cm, style={'fontName':'Helvetica-Bold','fontSize':12,'alignment':TA_CENTER}),
                    Label(text="Saldo Total", top=2.7*cm, left=17*cm, width=3.5*cm, style={'fontName':'Helvetica-Bold','fontSize':12,'alignment':TA_CENTER}),
                    Line(left=0, top=3.2*cm, right = 29.7*cm, bottom = 3.2*cm),]
        
    class band_detail(DetailBand):
        height = 0.7*cm
        elements = [
                    ObjectValue(attribute="", get_value=lambda instance:"%s" %instance['fecha'] if not isinstance(instance['fecha'], date) else "%s -- %s / %s" %(instance['fecha'].strftime("%d/%m/%Y"),instance['tipo'],instance['numero']),left=1*cm, width=7.5*cm, style={'fontName':'Helvetica','fontSize':11}),                
                    ObjectValue(attribute_name='total_c',get_value=lambda instance: "%.2f" %instance['total_c'] if isinstance(instance['total_c'],Decimal) else instance['debe'],left=10*cm, width=2.5*cm,style={'alignment':TA_RIGHT, 'fontName':'Helvetica','fontSize':11}),
                    ObjectValue(attribute_name='saldo_c',get_value=lambda instance: "%.2f" %instance['saldo_c'] if isinstance(instance['saldo_c'],Decimal) else instance['haber'],left=14*cm,width=2.5*cm,style={'alignment':TA_RIGHT, 'fontName':'Helvetica','fontSize':11}),
                    ObjectValue(attribute_name='saldo_t',get_value=lambda instance: "%.2f" %instance['saldo_t'] if isinstance(instance['saldo_t'],Decimal) else instance['saldo'],left=16.6*cm,width=2.5*cm,style={'alignment':TA_RIGHT, 'fontName':'Helvetica','fontSize':11}),      
                    ]
    groups=[
            ReportGroup(attribute_name='cliente_id',
                        band_header=ReportBand(
                                               height = 0.7*cm,
                                               borders = {'bottom': Line(stroke_color=black)},
                                               elements=[Label(text="CLIENTE:", top=0.1*cm, left=1*cm, 
                                                               style={'fontName':'Helvetica','fontSize':12}),
                                                         ObjectValue(attribute_name='cliente_id', top=0.1*cm, left=3*cm, style={'fontName':'Helvetica-Bold','fontSize':10}),
                                                         ObjectValue(attribute_name='razon_social', top=0.1*cm, left=4.5*cm, width=15*cm, style={'fontName':'Helvetica-Bold','fontSize':10}),
                                                         ])
                        )
            ]
    subreports=[
                SubReport(
                          queryset_string="%(object)s['detalle_venta']",
                          band_detail=ReportBand(
                                                 height=0.4*cm,
                                                 elements=[
                                                           ObjectValue(attribute_name='cantidad', get_value=lambda instance: "0.00" if instance['cantidad'].is_zero() else "%.2f" %instance['cantidad'], left=2.8*cm,style={'fontName':'Helvetica','fontSize':10}),
                                                           ObjectValue(attribute_name='articulo', truncate_overflow=True, height=0.4*cm, left=4*cm, width=10*cm, style={'fontName':'Helvetica','fontSize':10}),
                                                           ObjectValue(attribute_name='total', get_value=lambda instance: "0.00" if instance['total'].is_zero() else "%.2f" %instance['total'], left=15*cm, style={'fontName':'Helvetica','fontSize':10})]))]     