from boolean_app.models import Articulo, Venta, Recibo, Detalle_cobro, Cliente
from django.db.models import Q
from StringIO import StringIO
from django.http.response import HttpResponse
import json
from datetime import date
from django.core.urlresolvers import reverse_lazy
from decimal import Decimal
from pdb import set_trace

def _getattr_foreingkey(obj, attr):
    pt = attr.count('.')
    if pt == 0:#No hay clave foranea
        re = getattr(obj, attr)
        if isinstance(re, date):
            return re.strftime("%d/%m/%Y")
        if isinstance(re, Decimal):
            return "%.2f" %re
        else:
            return re
    else:
        nobj = getattr(obj, attr[:attr.find('.')])
        nattr = attr[attr.find('.')+1:]
        return _getattr_foreingkey(nobj,nattr)

def get_cantidad_tiempo(detalle):
    #set_trace()
    if detalle.tipo_articulo=="AA":
        if detalle.articulo and detalle.articulo.unidad_medida=="HS":
            mins = int(round((detalle.cantidad-int(detalle.cantidad))*60))
            return "%s:%s" %(int(detalle.cantidad),mins)
        else:
            return "%.2f" %detalle.cantidad
    else:
        return "%.2f" %detalle.cantidad

def get_cantidad_tiempo_ac(ac):
    if not ac.pers:
        if ac.articulo.unidad_medida=="HS":
            mins = int(round((ac.cantidad-int(ac.cantidad))*60))
            return "%s:%s" %(int(ac.cantidad),mins)
        else:
            return "%.2f" %ac.cantidad
    else:
        return "%.2f" %ac.cantidad


def format_det_venta(detalles_venta):
    html = """<table>
                <thead>
                    <tr>
                        <td>Cantidad</td>
                        <td>Articulo</td>
                        <td>P. Unitario</td
                        ><td>P. Total</td>
                    </tr>
                </thead>
                <tbody>"""
    for det in detalles_venta:
        html = html + "<tr><td>"+get_cantidad_tiempo(det)+"</td>"
        if det.articulo and det.tipo_articulo == "AA":
            html = html + "<td>"+det.articulo.codigo+" "+det.articulo.codigo_fabrica+" "+det.articulo.denominacion+"</td>"
        elif det.tipo_articulo == "AP":
            html = html + "<td>"+det.articulo_personalizado+"</td>"
        elif det.tipo_articulo == "AC":
            html = html + "<td><table><tbody>"
            acs = det.detallearticulocompuesto_set.all()
            for ac in acs:
                html = html + "<tr><td>"+get_cantidad_tiempo_ac(ac)+"</td>"
                if ac.articulo:
                    html = html + "<td>"+ac.articulo.denominacion+"</td>"
                elif ac.articulo_personalizado:
                    html = html + "<td>"+ac.articulo_personalizado+"</td>"
                html = html + "<td>"+"%.2f" %ac.precio_unitario+"</td>"
                html = html + "<td>"+"%.2f" %ac.neto+"</td>"
                html = html + "</tr>"
            html = html + "</tbody></table></td>"
        html = html + "<td>"+"%.2f" %det.precio_unitario+"</td>"
        html = html + "<td>"+"%.2f" %det.total_con_descuento+"</td>"
        html = html + "</tr>"
    html = html + "</tbody></table>"
    return html
    

def articulo_datatables_view(request):
    objects = Articulo.objects.all()
    desde = request.GET['desde']
    es_b = True if 'es_b' in request.GET else False
    print es_b
    if desde == 'seleccionArticulo':
        list_display = ['pk','codigo', 'codigo_fabrica','denominacion','rubro.nombre','precio_venta']
        #list_filter = ['codigo', 'codigo_fabrica','denominacion']
    elif desde == 'mainArticulos':
        list_display = ['codigo', 'codigo_fabrica','denominacion','linea.nombre','rubro.nombre','ultima_actualizacion_precio']
        list_filter = ['codigo', 'codigo_fabrica','denominacion','linea__nombre','rubro__nombre']
    
    # Cuenta total de articulos:
    recordsTotal = objects.count()

    #Filtrado de los articulos
    search = request.GET['search[value]']
    if desde == 'seleccionArticulo':
        queries = []
        qcodigo = Q(**{'codigo__contains' : search})
        queries.append(qcodigo)
        qcodigo_fabrica = Q(**{'codigo_fabrica__contains' : search})
        queries.append(qcodigo_fabrica)
        qdenocontains = Q(**{'denominacion__contains' : search})
        queries.append(qdenocontains)
        deno = ""
        if search:
            for pa in search.replace("  "," ").split(" "):
                if pa and pa is not " ":
                    deno = deno + "+"+pa+" "
            #set_trace()
            print deno
            qdenominacion = Q(**{'denominacion__search' : deno})
            queries.append(qdenominacion)        
        #queries = [Q(**{f+'__contains' : search}) for f in list_filter]
        qs = reduce(lambda x, y: x|y, queries)
        objects = objects.filter(qs)
    elif desde == 'mainArticulos':
        queries = [Q(**{f+'__contains' : search}) for f in list_filter]
        qs = reduce(lambda x, y: x|y, queries)
        objects = objects.filter(qs)

    #Ordenado
    #order = dict( enumerate(list_display) )
    #dirs = {'asc': '', 'desc': '-'}
    #ordering = dirs[request.GET['sSortDir_0']] + order[int(request.GET['iSortCol_0'])]
    #objects = objects.order_by(ordering)

    # Conteo de articulos despues dle filtrado
    recordsFiltered = objects.count()


    # finally, slice according to length sent by dataTables:
    start = int(request.GET['start'])
    length = int(request.GET['length'])
    objects = objects[ start : (start+length)]
    
    # extract information
    #data = [map(lambda field: _getattr_foreingkey(obj, field), list_display) for obj in objects]
    data = []
    for obj in objects:
        row=map(lambda field: _getattr_foreingkey(obj, field), list_display)
        if es_b:
            row[5]= obj.precio_venta_iva_inc
        if desde == 'mainArticulos':
            ops = '<a href="%s">EDITAR</a>  --  <a href="%s">BORRAR</a>' %(reverse_lazy('editarArticulo',args=[obj.pk]),reverse_lazy('borrarArticulo',args=[obj.pk])) 
            row.append(ops)
        data.append(row)
        

    #define response
    response = {
        'data': data,
        'recordsTotal': recordsTotal,
        'recordsFiltered': recordsFiltered,
        'draw': request.GET['draw']
    }

    #serialize to json
    s = StringIO()
    json.dump(response, s)
    s.seek(0)
    return HttpResponse(s.read())

def comp_datatables_view(request):
    comprobantes = Venta.objects.all()
    list_display = ['fecha', 'tipo','pto_vta_num_full','cliente.razon_social','neto','iva21','total','aprobado']
    list_filter = ['cliente__razon_social']

    # Cuenta total de articulos:
    recordsTotal = comprobantes.count()

    #Filtrado de los articulos
    search = request.GET['search[value]']
    queries = [Q(**{f+'__contains' : search}) for f in list_filter]
    qs = reduce(lambda x, y: x|y, queries)
    comprobantes = comprobantes.filter(qs)

    #Ordenado
    #order = dict( enumerate(list_display) )
    #dirs = {'asc': '', 'desc': '-'}
    #ordering = dirs[request.GET['sSortDir_0']] + order[int(request.GET['iSortCol_0'])]
    #objects = objects.order_by(ordering)

    # Conteo de articulos despues dle filtrado
    recordsFiltered = comprobantes.count()


    # finally, slice according to length sent by dataTables:
    start = int(request.GET['start'])
    length = int(request.GET['length'])
    comprobantes = comprobantes[ start : (start+length)]
    
    # extract information
    #data = [map(lambda field: _getattr_foreingkey(obj, field), list_display) for obj in objects]
    data = []
    for obj in comprobantes:
        row=map(lambda field: _getattr_foreingkey(obj, field), list_display)
        detalles_venta_html = format_det_venta(obj.detalle_venta_set.all())
        row.insert(0,detalles_venta_html)
        if row[-1]:
            row[-1]="Aprobado"
        else:
            row[-1]="Borrador"
            row[3]="N/A"
        ops = '<a class="imprimirComprobante" href="%s">IMPRIMIR</a>' %(reverse_lazy('imprimirComprobante',args=[obj.pk])) if obj.aprobado else "" 
        row.append(ops)
        #Es un table (<table>..........</table>
        data.append(row)
        

    #define response
    response = {
        'data': data,
        'recordsTotal': recordsTotal,
        'recordsFiltered': recordsFiltered,
        'draw': request.GET['draw']
    }

    #serialize to json
    s = StringIO()
    json.dump(response, s)
    s.seek(0)
    return HttpResponse(s.read())

def cobros_datatables_view(request):
    cobros = Recibo.objects.all()
    #Campos directos, personalizacion mas adelante
    list_display = ['fecha', 'numero_full','cliente.razon_social','total_str']
    list_filter = ['cliente__razon_social']

    # Cuenta total de articulos:
    recordsTotal = cobros.count()

    #Filtrado de los articulos
    search = request.GET['search[value]']
    queries = [Q(**{f+'__contains' : search}) for f in list_filter]
    qs = reduce(lambda x, y: x|y, queries)
    cobros = cobros.filter(qs)

    #Ordenado
    #order = dict( enumerate(list_display) )
    #dirs = {'asc': '', 'desc': '-'}
    #ordering = dirs[request.GET['sSortDir_0']] + order[int(request.GET['iSortCol_0'])]
    #objects = objects.order_by(ordering)

    # Conteo de articulos despues dle filtrado
    recordsFiltered = cobros.count()


    # finally, slice according to length sent by dataTables:
    start = int(request.GET['start'])
    length = int(request.GET['length'])
    cobros = cobros[ start : (start+length)]
    
    # extract information
    #data = [map(lambda field: _getattr_foreingkey(obj, field), list_display) for obj in objects]
    data = []
    for obj in cobros:
        row=map(lambda field: _getattr_foreingkey(obj, field), list_display)
        detalle_pago = Detalle_cobro.objects.filter(recibo=obj)
        det = ""
        for detalle in detalle_pago:
            det = det + "%s<br>" %detalle.venta 
        row.insert(3, det)
        ops = '<a class="imprimirRecibo" href="%s">IMPRIMIR</a>' %(reverse_lazy('imprimirRecibo',args=[obj.pk])) 
        row.append(ops)
        data.append(row)
        
    #set_trace()
    #define response
    response = {
        'data': data,
        'recordsTotal': recordsTotal,
        'recordsFiltered': recordsFiltered,
        'draw': request.GET['draw']
    }

    #serialize to json
    s = StringIO()
    json.dump(response, s)
    s.seek(0)
    return HttpResponse(s.read())

def get_comprobantes_de_cliente(request,cliente):
    cliente = Cliente.objects.get(id=cliente)
    comprs = Venta.objects.filter(cliente=cliente,pagado=False)
    data = []
    for com in comprs:
        obj = {"id":com.id,"comprobante":"%s" %com}
        data.append(obj)
    s = StringIO()
    json.dump(data,s)
    s.seek(0)
    return HttpResponse(s.read())

def get_credito_valores(request,cliente):
    cliente = Cliente.objects.get(id=cliente)
    for rec in cliente.recibo_set.all():
        for valor in rec.valores_set.all():
            if valor.pendiente_para_recibo > 0.009 and valor.tipo=='CHT':
                obj = {'num_cheque':valor.cheque_numero, 'pendiente':'%.2f' %valor.pendiente_para_recibo}
                s = StringIO()
                json.dump(obj,s)
                s.seek(0)
                return HttpResponse(s.read())
    return HttpResponse()