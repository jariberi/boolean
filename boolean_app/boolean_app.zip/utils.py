from boolean.settings import PUNTO_VENTA_FAA, PUNTO_VENTA_FAB, PUNTO_VENTA_NCA,\
    PUNTO_VENTA_NCB, PUNTO_VENTA_NDA, PUNTO_VENTA_NDB
from boolean_app.models import Venta, Recibo

def sum_num_comp(venta):
    if venta.tipo == "FAA":
        PUNTO_VENTA_FAA += 1
    elif venta.tipo == "FAB":
        PUNTO_VENTA_FAB += 1
    elif venta.tipo == "NCA":
        PUNTO_VENTA_NCA += 1
    elif venta.tipo == "NCB":
        PUNTO_VENTA_NCB += 1
    elif venta.tipo == "NDA":
        PUNTO_VENTA_NDA += 1
    elif venta.tipo == "NDB":
        PUNTO_VENTA_NDB += 1

def get_pto_vta(venta):
    if venta.tipo == "FAA":
        return PUNTO_VENTA_FAA
    elif venta.tipo == "FAB":
        return PUNTO_VENTA_FAB
    elif venta.tipo == "NCA":
        return PUNTO_VENTA_NCA
    elif venta.tipo == "NCB":
        return PUNTO_VENTA_NCB
    elif venta.tipo == "NDA":
        return PUNTO_VENTA_NDA
    elif venta.tipo == "NDB":
        return PUNTO_VENTA_NDB

def get_num_comp(venta):
    list_comprob = Venta.objects.filter(tipo=venta.tipo,aprobado__exact=True).order_by('-numero')
    if len(list_comprob) != 0:
        return list_comprob[0].numero+1
    else:
        return 1
    
def get_tipo_comp_afip (venta):
    if venta.tipo == "FAA":
        return 1
    elif venta.tipo == "FAB":
        return 6
    elif venta.tipo == "NCA":
        return 3
    elif venta.tipo == "NCB":
        return 8
    elif venta.tipo == "NDA":
        return 2
    elif venta.tipo == "NDB":
        return 7
    
def get_num_recibo():
    list_recibo = Recibo.objects.all().order_by('-numero')
    if len(list_recibo) != 0:
        return list_recibo[0].numero+1
    else:
        return 1
    
def getattr_foreingkey(obj, attr):
    pt = attr.count('.')
    if pt == 0:#No hay clave foranea
        return getattr(obj, attr)
    else:
        nobj = getattr(obj, attr[:attr.find('.')])
        nattr = attr[attr.find('.')+1:]
        getattr(nobj,nattr)
        