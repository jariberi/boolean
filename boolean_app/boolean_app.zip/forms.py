'''
Created on 01/08/2014

@author: jorge
'''
from django.forms.models import ModelForm
from boolean_app.models import Venta, Detalle_venta, Periodo, Recibo, Valores, DetalleArticuloCompuesto,\
    Cliente
from django import forms
from django.forms.forms import Form

class FacturaForm(ModelForm):
    class Meta:
        model = Venta
        exclude = ('articulos',)
        widgets = {
                   'comprobantes_relacionados': forms.SelectMultiple(attrs={'data-placeholder':"Elija uno o mas comprobantes"}),
                   }

        
class DetalleVentaForm(ModelForm):
    class Meta:
        model = Detalle_venta
        exclude = ('venta',)
        widgets = {
                   #'articulo': forms.Select(attrs={'class':'articulo_select'}),
                   'articulo': forms.HiddenInput(attrs={'class':'articulo_input'}),
                   'tipo_articulo': forms.Select(attrs={'class':'tipo_articulo_select'}),
                   'precio_unitario': forms.TextInput(attrs={'class':'precio_unitario_input'}),
                   'linea_articulo_personalizado': forms.Select(attrs={'class':'linea_articulo_personalizado_select'}),
                   'cantidad': forms.TextInput(attrs={'class':'cantidad_input'}),
                   'descuento': forms.TextInput(attrs={'class':'descuento_input'}),
                   'articulo_personalizado': forms.Textarea(attrs={'class':'articulo_personalizado_input','rows':5, 'cols':20})
        }
        
class DetalleArticulosCompuestosForm(ModelForm):
    id_detalle_venta = forms.CharField(widget=forms.HiddenInput({'class':'id_detalle_venta_hidden'}))
    
    class Meta:
        model = DetalleArticuloCompuesto
        exclude = ('detalle_venta',)
        widgets = {'pers': forms.CheckboxInput(attrs={'class':'pers_checkbox'}),                   
                   'articulo': forms.HiddenInput(attrs={'class':'articulo_input'}),
                   'precio_unitario': forms.TextInput(attrs={'class':'precio_unitario_input'}),
                   'linea_articulo_personalizado': forms.Select(attrs={'class':'linea_articulo_personalizado_select'}),
                   'cantidad': forms.TextInput(attrs={'class':'cantidad_input'}),
                   'articulo_personalizado': forms.Textarea(attrs={'class':'articulo_personalizado_input','rows':5, 'cols':20})
                   }
        
class SubdiarioIVAPeriodoFecha(Form):
    folio_inicial = forms.IntegerField(min_value=1, initial=1)
    periodo = forms.ModelChoiceField(queryset=Periodo.objects.all(), required=False)
    fecha_desde = forms.DateField(required=False)
    fecha_hasta = forms.DateField(required=False)
    
    def clean(self):
        cleaned_data = super(SubdiarioIVAPeriodoFecha, self).clean()
        periodo = cleaned_data.get("periodo")
        fd = cleaned_data.get("fecha_desde")
        fh = cleaned_data.get("fecha_hasta")
        
        if fd and fh:
            if periodo:
                raise forms.ValidationError("Debe seleccionar o un periodo o las fechas desde y hasta. No ambas condiciones.")
        elif periodo:
            if fd or fh:
                raise forms.ValidationError("Debe seleccionar o un periodo o las fechas desde y hasta. No ambas condiciones.")
        elif not fd and not fh and not periodo:
            raise forms.ValidationError("Debe seleccionar un periodo o las fechas desde y hasta.")
        
        return cleaned_data
        
class ReciboForm(ModelForm):
    class Meta:
        model = Recibo
        exclude = ('venta',)
        widgets = {
                   'cliente': forms.Select(attrs={'data-placeholder':'Elija un cliente...'}),
                   }
        
class DetalleCobroForm(Form):
    pagar = forms.DecimalField(widget=forms.TextInput(attrs={'class':'entrega_input'}))
    id_factura = forms.CharField(widget=forms.HiddenInput(attrs={'class':'id_factura'}))
    
class ValoresForm(ModelForm):
    class Meta:
        model = Valores
        exclude = ('recibo','pendiente_para_recibo')
        widgets = {
                   'tipo': forms.Select(attrs={'class':'tipo_valor_select'}),
                   'cheque_numero': forms.TextInput(attrs={'placeholder':'Nro. Cheque'}),
                   'cheque_fecha': forms.TextInput(attrs={'placeholder':'Fecha de emision del cheque'}),
                   'cheque_cobro': forms.TextInput(attrs={'placeholder':'Fecha de cobro del cheque'}),
                   'cheque_titular': forms.TextInput(attrs={'placeholder':'Titular del cheque'}),
                   'cheque_cuit_titular': forms.TextInput(attrs={'placeholder':'CUIT del titular del cheque, con guiones'}),
                   'cheque_paguese_a': forms.TextInput(attrs={'placeholder':'Paguese a'}),
                   'cheque_domicilio_de_pago': forms.TextInput(attrs={'placeholder':'Domicilio de pago del cheque'}),
                   'transferencia_cuenta_origen': forms.TextInput(attrs={'placeholder':'Cuenta origen de la transferencia'}),
                   'transferencia_numero_operacion': forms.TextInput(attrs={'placeholder':'Numero de operacion'}),
                   'monto': forms.TextInput(attrs={'class':'monto_input'}),
                  }
        
class ActualizarPrecioRubrosForm(Form):
    rubro = forms.IntegerField(widget=forms.HiddenInput())
    porcentaje = forms.DecimalField()
    
class VentasTotalesForm(Form):
    fecha_desde = forms.DateField()
    fecha_hasta = forms.DateField()
    
class ResumenCuentaForm(Form):
    LISTAR_CHOICES=[('UNO','Listar un cliente'),
                    ('TODOS','Listar todos los clientes')]
    
    listar=forms.ChoiceField(choices=LISTAR_CHOICES, widget=forms.RadioSelect())
    cliente=forms.ModelChoiceField(queryset=Cliente.objects.all(),required=False)
    desde=forms.DateField()
    hasta=forms.DateField()
    
    
class ComposicionSaldoForm(Form):
    LISTAR_CHOICES=[('UNO','Listar un cliente'),
                    ('TODOS','Listar todos los clientes')]
    TIPO_CHOICES=[('SIMPLE','Simple'),
                  ('DETALLADO','Detallado')]
    
    listar=forms.ChoiceField(choices=LISTAR_CHOICES, widget=forms.RadioSelect())
    tipo=forms.ChoiceField(choices=TIPO_CHOICES, widget=forms.RadioSelect())
    cliente=forms.ModelChoiceField(queryset=Cliente.objects.all(),required=False)